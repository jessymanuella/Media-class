package mediaRentalManager;

public class Media implements Comparable<Media> {

	private int copiesAvailable;
	private String title;
	
	/**
	 * This c
	 * @param title
	 * @param copiesAvailable
	 */

	public Media(String title, int copiesAvailable) {
		this.title = title;
		this.copiesAvailable = copiesAvailable;
	}
	
	/**
	 * This method creates a copy constructor of the Media class.
	 * @param media
	 */

	public Media(Media media) {
		this(media.title, media.copiesAvailable);

	}
	
	/**
	 * This method returns the title.
	 * @return
	 */

	public String getTitle() {
		return title;
	}
	
	/**
	 * This method returns the copies available.
	 * @return
	 */

	public int getCopiesAvailable() {
		return copiesAvailable;
	}
	
	/**
	 * This method adds the number to the instances of copies available.
	 * @param num
	 */

	public void setUpdateCopies(int num) {
		this.copiesAvailable += num;
	}
	
	/**
	 * This methods allows the string representation of the object. It will allow you to print the title and copies available.
	 */

	public String toString() {
		return "\nTitle: " + this.title + ", Copies Available: " + 
	this.copiesAvailable;
	}
	
	/**
	 * This method allows you to compare the instance of
	 */

	@Override
	public int compareTo(Media media) {
		return this.title.compareTo(media.title);
	}

}
